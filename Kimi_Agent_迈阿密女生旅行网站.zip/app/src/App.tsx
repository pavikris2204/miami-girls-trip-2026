import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import confetti from 'canvas-confetti';
import { 
  Heart, 
  Calendar, 
  MapPin, 
  DollarSign, 
  CheckCircle2, 
  Sparkles,
  Coffee,
  Wine,
  Plane,
  ShoppingBag,
  Utensils,
  Star,
  TrendingUp,
  PartyPopper,
  Waves,
  MessageCircle,
  Plus,
  X,
  GripVertical,
  Edit3,
  Trash2,
  Send,
  Map,
  Home,
  Navigation,
  Share2,
  Download,
  Upload,
  Info,
  RefreshCw
} from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  type DragEndEvent,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import './App.css';

// Types
interface Comment {
  id: string;
  user: string;
  text: string;
  timestamp: number;
}

interface Activity {
  id: string;
  time: string;
  title: string;
  place: string | null;
  desc: string;
  price: string;
  tag: string;
  votes: number;
  votedBy: string[];
  comments: Comment[];
  lat?: number;
  lng?: number;
}

interface Day {
  id: string;
  label: string;
  date: string;
  vibe: string;
  accent: string;
  bg: string;
  stripe: string;
  budget: string;
  activities: Activity[];
  icon: React.ReactNode;
}

interface PackingItem {
  id: string;
  item: string;
  category: string;
  checked: boolean;
}

interface TripData {
  days: Day[];
  packingList: PackingItem[];
  lastUpdated: number;
  updatedBy: string;
}

// Generate unique ID
const generateId = () => Math.random().toString(36).substr(2, 9);

// Initial data
const createInitialDays = (): Day[] => [
  {
    id: "mon",
    label: "Monday",
    date: "Mar 16",
    vibe: "Arrival Day ✈️",
    accent: "#FF3CAC",
    bg: "#fff0f7",
    stripe: "#FF3CAC",
    budget: "$55–75",
    icon: null,
    activities: [
      {
        id: generateId(),
        time: "Afternoon",
        title: "Land & Check In",
        place: "1200 Brickell Bay Dr, Miami, FL 33131",
        desc: "Uber from MIA straight to the Brickell Airbnb. Dump the bags, throw open the windows, do the first group mirror selfie. You're here.",
        price: "~$5/person (split Uber)",
        tag: "transport",
        votes: 0,
        votedBy: [],
        comments: [],
        lat: 25.7614,
        lng: -80.1881,
      },
      {
        id: generateId(),
        time: "5 PM",
        title: "Publix Grocery Run",
        place: "Publix, 134 SW 13th St — walkable",
        desc: "This is the move that saves you $100+ over the week. Stock up on breakfast stuff, snacks, drinks, and anything for pregaming.",
        price: "$20–25/person for the whole week",
        tag: "smart",
        votes: 0,
        votedBy: [],
        comments: [],
        lat: 25.7665,
        lng: -80.1934,
      },
      {
        id: generateId(),
        time: "6:30 PM",
        title: "First Coffee: Studio 24 Artful Coffee",
        place: "1250 S Miami Ave — 2 min walk",
        desc: "A genuinely beautiful café right in Brickell. The pistachio truffle latte has been everywhere on the internet for a reason.",
        price: "$7–9",
        tag: "cafe",
        votes: 0,
        votedBy: [],
        comments: [],
        lat: 25.7654,
        lng: -80.1939,
      },
      {
        id: generateId(),
        time: "8 PM",
        title: "First Night Out: Rosa Sky Rooftop",
        place: "115 SW 8th St, 22nd Floor — 5 min walk",
        desc: "A rooftop bar that feels way fancier than the tab. 22 floors up, full Brickell skyline, killer cocktails. Happy hour until 8PM weekdays!",
        price: "$35–45 for 2–3 drinks",
        tag: "nightlife",
        votes: 0,
        votedBy: [],
        comments: [],
        lat: 25.7702,
        lng: -80.1964,
      },
    ],
  },
  {
    id: "tue",
    label: "Tuesday",
    date: "Mar 17",
    vibe: "Beach + Aesthetic Spots 🏖️",
    accent: "#FF6B35",
    bg: "#fff7f0",
    stripe: "#FF6B35",
    budget: "$65–90",
    icon: null,
    activities: [
      {
        id: generateId(),
        time: "9 AM",
        title: "Breakfast at the Airbnb",
        place: "1200 Brickell Bay Dr, Miami, FL 33131",
        desc: "Use the Publix haul. Eggs, toast, coffee from the machine. Bank this $15 for something better later.",
        price: "Already paid for",
        tag: "smart",
        votes: 0,
        votedBy: [],
        comments: [],
        lat: 25.7614,
        lng: -80.1881,
      },
      {
        id: generateId(),
        time: "10:30 AM",
        title: "South Pointe Beach",
        place: "1 Washington Ave, South Beach",
        desc: "The prettiest stretch of the whole beach. Whiter sand, less crowded than the main strip, turquoise water that actually looks tropical.",
        price: "Free. Chair rental optional ~$8/person",
        tag: "beach",
        votes: 0,
        votedBy: [],
        comments: [],
        lat: 25.7681,
        lng: -80.1313,
      },
      {
        id: generateId(),
        time: "1 PM",
        title: "Lunch: Cielito Artisan Pops + Wander",
        place: "2750 NW 3rd Ave, Wynwood",
        desc: "Swing through Wynwood after the beach. The murals are free. Grab popsicles at Cielito — 46+ flavours including jalapeño pineapple!",
        price: "$8–12 for pops + free street art",
        tag: "food",
        votes: 0,
        votedBy: [],
        comments: [],
        lat: 25.7995,
        lng: -80.1994,
      },
      {
        id: generateId(),
        time: "3 PM",
        title: "Paradox Museum",
        place: "2301 N Miami Ave, Wynwood",
        desc: "Optical illusions, mind-bending installations, rooms purpose-built for group photos. The staff literally help you pose!",
        price: "$25–30/person. Book online.",
        tag: "activity",
        votes: 0,
        votedBy: [],
        comments: [],
        lat: 25.8003,
        lng: -80.1989,
      },
      {
        id: generateId(),
        time: "7 PM",
        title: "Dinner: DC Pie Co.",
        place: "1010 Brickell Ave — near your Airbnb",
        desc: "Brickell's best kept secret. NYC-style wood-fired pizza, kale Caesar that converts people who don't like kale, great cocktails.",
        price: "$20–28/person with drinks",
        tag: "food",
        votes: 0,
        votedBy: [],
        comments: [],
        lat: 25.7651,
        lng: -80.1936,
      },
      {
        id: generateId(),
        time: "10 PM",
        title: "Ocean Drive Walk",
        place: "Ocean Dr, Miami Beach",
        desc: "After dinner, Uber to Ocean Drive and just walk it. Neon-lit Art Deco buildings, people everywhere, street performers.",
        price: "$10–15 for one drink",
        tag: "nightlife",
        votes: 0,
        votedBy: [],
        comments: [],
        lat: 25.7807,
        lng: -80.1303,
      },
    ],
  },
  {
    id: "wed",
    label: "Wednesday",
    date: "Mar 18",
    vibe: "Culture + Party Night 💃",
    accent: "#FFBD00",
    bg: "#fffdf0",
    stripe: "#FFBD00",
    budget: "$90–130",
    icon: null,
    activities: [
      {
        id: generateId(),
        time: "9 AM",
        title: "Breakfast at A Family Brickell",
        place: "41 SE 5th St — walkable",
        desc: "A tiny Argentinian café right in Brickell. The empanadas are genuinely the best in Miami — beef chimichurri, chicken teriyaki, caprese.",
        price: "$9–12",
        tag: "food",
        votes: 0,
        votedBy: [],
        comments: [],
        lat: 25.7682,
        lng: -80.1931,
      },
      {
        id: generateId(),
        time: "11 AM",
        title: "Frost Science Museum",
        place: "1101 Biscayne Blvd, Downtown",
        desc: "Don't let 'science museum' fool you. It's stunning — a massive multi-level aquarium where you look UP at sharks and rays!",
        price: "$30–35/person. Book online.",
        tag: "activity",
        votes: 0,
        votedBy: [],
        comments: [],
        lat: 25.7863,
        lng: -80.1869,
      },
      {
        id: generateId(),
        time: "2 PM",
        title: "Lunch: Sandwich Miami",
        place: "34 SW 8th St, Brickell",
        desc: "Fresh French-style sandwiches with massive portions. Turkey brie avocado, grilled veggie, housemade dressings.",
        price: "$12–16",
        tag: "food",
        votes: 0,
        votedBy: [],
        comments: [],
        lat: 25.7698,
        lng: -80.1961,
      },
      {
        id: generateId(),
        time: "5 PM",
        title: "Explore Brickell City Centre",
        place: "701 S Miami Ave — walkable",
        desc: "The architecture alone is worth seeing — a dramatic open-air climate ribbon runs through the whole mall.",
        price: "Free to explore. Shop what you want.",
        tag: "activity",
        votes: 0,
        votedBy: [],
        comments: [],
        lat: 25.7674,
        lng: -80.1930,
      },
      {
        id: generateId(),
        time: "8 PM",
        title: "Little Havana: Ball & Chain",
        place: "1513 SW 8th St, Calle Ocho",
        desc: "One of the best nights out in Miami! Live salsa band, dancers on stage, incredible mojitos, outdoor garden.",
        price: "$0–20 cover + $12–15 drinks",
        tag: "nightlife",
        votes: 0,
        votedBy: [],
        comments: [],
        lat: 25.7653,
        lng: -80.2265,
      },
    ],
  },
  {
    id: "thu",
    label: "Thursday",
    date: "Mar 19",
    vibe: "Beach Club + Wynwood Night 🌴",
    accent: "#E8007D",
    bg: "#fff0f8",
    stripe: "#E8007D",
    budget: "$90–130",
    icon: null,
    activities: [
      {
        id: generateId(),
        time: "9:30 AM",
        title: "Brunch: Wilde on the Porch",
        place: "1700 Collins Ave, Miami Beach",
        desc: "Outdoor porch restaurant on Collins Ave. The fried snapper is incredible, the cocktails are generous, and there's hookah!",
        price: "$22–30/person with one drink",
        tag: "food",
        votes: 0,
        votedBy: [],
        comments: [],
        lat: 25.7921,
        lng: -80.1305,
      },
      {
        id: generateId(),
        time: "12 PM",
        title: "South Beach Afternoon",
        place: "South Pointe Beach",
        desc: "Another beach day — but now you know where to go and you're not wasting time figuring it out. Stay until golden hour!",
        price: "Free",
        tag: "beach",
        votes: 0,
        votedBy: [],
        comments: [],
        lat: 25.7681,
        lng: -80.1313,
      },
      {
        id: generateId(),
        time: "4 PM",
        title: "Aura Matcha",
        place: "1510 Collins Ave, Miami Beach",
        desc: "The best matcha you'll find in Miami, sourced from Japan. The shop is cute, the drinks are beautiful!",
        price: "$7–9",
        tag: "cafe",
        votes: 0,
        votedBy: [],
        comments: [],
        lat: 25.7905,
        lng: -80.1312,
      },
      {
        id: generateId(),
        time: "7 PM",
        title: "Dinner: KYU Miami",
        place: "251 NW 25th St, Wynwood",
        desc: "Asian wood-fired kitchen in the heart of Wynwood. Order to share: spicy tuna crispy rice, short ribs, the cauliflower.",
        price: "$40–55/person shared dishes. Reserve ahead.",
        tag: "splurge",
        votes: 0,
        votedBy: [],
        comments: [],
        lat: 25.8006,
        lng: -80.1996,
      },
      {
        id: generateId(),
        time: "10 PM",
        title: "Wynwood Bars",
        place: "NW 2nd Ave area, Wynwood",
        desc: "After dinner, just walk Wynwood. It comes alive at night — every bar has a different energy, murals are lit up!",
        price: "$10–20 for drinks",
        tag: "nightlife",
        votes: 0,
        votedBy: [],
        comments: [],
        lat: 25.8011,
        lng: -80.1995,
      },
    ],
  },
  {
    id: "fri",
    label: "Friday",
    date: "Mar 20",
    vibe: "The Big Night 🎉",
    accent: "#FF3CAC",
    bg: "#fff0f7",
    stripe: "#FF3CAC",
    budget: "$110–160",
    icon: null,
    activities: [
      {
        id: generateId(),
        time: "10 AM",
        title: "Slow Start: Bon Bouquet Café",
        place: "3865 Indian Creek Dr, Miami Beach",
        desc: "The most beautiful brunch café in Miami Beach. Flower walls, photo-printed lattes, Benedict's, crepes.",
        price: "$18–25. Book ahead.",
        tag: "food",
        votes: 0,
        votedBy: [],
        comments: [],
        lat: 25.8121,
        lng: -80.1234,
      },
      {
        id: generateId(),
        time: "1 PM",
        title: "Lincoln Road + Shopping",
        place: "Lincoln Road Mall, Miami Beach",
        desc: "Take the free Miami Beach Trolley. Pedestrian street full of shops, local boutiques, outdoor vendors.",
        price: "Free trolley. Shopping budget is yours.",
        tag: "activity",
        votes: 0,
        votedBy: [],
        comments: [],
        lat: 25.7906,
        lng: -80.1369,
      },
      {
        id: generateId(),
        time: "3:30 PM",
        title: "Bayside Marketplace",
        place: "401 Biscayne Blvd, Downtown",
        desc: "Waterfront marketplace on Biscayne Bay. Live music most afternoons, good happy hour spots, boats coming in and out.",
        price: "Free to wander. Drinks ~$12",
        tag: "activity",
        votes: 0,
        votedBy: [],
        comments: [],
        lat: 25.7785,
        lng: -80.1867,
      },
      {
        id: generateId(),
        time: "7 PM",
        title: "Dinner: Sexy Fish Miami",
        place: "1001 S Miami Ave — walkable from Airbnb",
        desc: "Your second and best splurge dinner. The interior is insane — art on every surface, dramatic lighting!",
        price: "$65–80/person. Book days ahead.",
        tag: "splurge",
        votes: 0,
        votedBy: [],
        comments: [],
        lat: 25.7650,
        lng: -80.1935,
      },
      {
        id: generateId(),
        time: "9:30 PM",
        title: "Pregame at the Airbnb",
        place: "1200 Brickell Bay Dr, Miami, FL 33131",
        desc: "The ritual. Music on, everyone getting dressed, Publix drinks, roof-of-the-world feeling. This is free and one of the best parts!",
        price: "Free (already paid for at Publix)",
        tag: "smart",
        votes: 0,
        votedBy: [],
        comments: [],
        lat: 25.7614,
        lng: -80.1881,
      },
      {
        id: generateId(),
        time: "11:30 PM",
        title: "E11EVEN Miami",
        place: "29 NE 11th St, Downtown",
        desc: "Miami's wildest club — 24 hours, performers, world-class DJs, aerialists. Buy GA tickets online before the trip (~$30).",
        price: "$30 GA ticket + $20/drink. Pregame at home.",
        tag: "nightlife",
        votes: 0,
        votedBy: [],
        comments: [],
        lat: 25.7849,
        lng: -80.1938,
      },
    ],
  },
  {
    id: "sat",
    label: "Saturday",
    date: "Mar 21",
    vibe: "Bye Miami 👋",
    accent: "#FF6B35",
    bg: "#fff7f0",
    stripe: "#FF6B35",
    budget: "$15–25",
    icon: null,
    activities: [
      {
        id: generateId(),
        time: "Morning",
        title: "Sleep. Hydrate.",
        place: "1200 Brickell Bay Dr, Miami, FL 33131",
        desc: "You earned this. Lie around, eat whatever's left from the Publix haul, make a group chat collage of the week's photos.",
        price: "Free",
        tag: "smart",
        votes: 0,
        votedBy: [],
        comments: [],
        lat: 25.7614,
        lng: -80.1881,
      },
      {
        id: generateId(),
        time: "11 AM",
        title: "Last Bite: Cuban Coffee & Pastelito",
        place: "Any café on Brickell Ave",
        desc: "One last proper Miami moment before you leave. A café con leche and a pastelito de guayaba from a Cuban bakery.",
        price: "$5–8",
        tag: "food",
        votes: 0,
        votedBy: [],
        comments: [],
        lat: 25.7650,
        lng: -80.1900,
      },
      {
        id: generateId(),
        time: "1 PM",
        title: "Pack Up, Check Out",
        place: "1200 Brickell Bay Dr, Miami, FL 33131",
        desc: "Leave the Airbnb how you found it, do a sweep, take one last photo on whatever rooftop or balcony you have access to.",
        price: "~$5/person for Uber",
        tag: "transport",
        votes: 0,
        votedBy: [],
        comments: [],
        lat: 25.7614,
        lng: -80.1881,
      },
      {
        id: generateId(),
        time: "4 PM",
        title: "Flight Home",
        place: "MIA or FLL",
        desc: "Fly home tanned, tired, and deeply satisfied.",
        price: "Already booked",
        tag: "transport",
        votes: 0,
        votedBy: [],
        comments: [],
        lat: 25.7959,
        lng: -80.2870,
      },
    ],
  },
];

const tagStyles: Record<string, { bg: string; color: string; icon: React.ReactNode }> = {
  transport: { bg: "#f0f0f0", color: "#666", icon: <Plane className="w-3 h-3" /> },
  smart: { bg: "#e8f5e9", color: "#2e7d32", icon: <Star className="w-3 h-3" /> },
  cafe: { bg: "#fff3e0", color: "#e65100", icon: <Coffee className="w-3 h-3" /> },
  food: { bg: "#fce4ec", color: "#c62828", icon: <Utensils className="w-3 h-3" /> },
  beach: { bg: "#e3f2fd", color: "#1565c0", icon: <Waves className="w-3 h-3" /> },
  activity: { bg: "#f3e5f5", color: "#6a1b9a", icon: <Sparkles className="w-3 h-3" /> },
  nightlife: { bg: "#fbe9e7", color: "#bf360c", icon: <Wine className="w-3 h-3" /> },
  splurge: { bg: "#fff8e1", color: "#f57f17", icon: <DollarSign className="w-3 h-3" /> },
};

const tagLabels: Record<string, string> = {
  transport: "transport",
  smart: "money saver",
  cafe: "café",
  food: "food",
  beach: "beach",
  activity: "activity",
  nightlife: "night out",
  splurge: "splurge",
};

const initialPackingList: PackingItem[] = [
  { id: "1", item: "Bikinis / Swimsuits", category: "clothes", checked: false },
  { id: "2", item: "Beach cover-ups", category: "clothes", checked: false },
  { id: "3", item: "Cute dinner outfits (2-3)", category: "clothes", checked: false },
  { id: "4", item: "Comfy walking shoes", category: "clothes", checked: false },
  { id: "5", item: "Heels for nightlife", category: "clothes", checked: false },
  { id: "6", item: "Sunscreen (SPF 50+)", category: "essentials", checked: false },
  { id: "7", item: "Sunglasses", category: "essentials", checked: false },
  { id: "8", item: "Phone charger / portable battery", category: "essentials", checked: false },
  { id: "9", item: "Camera / GoPro", category: "essentials", checked: false },
  { id: "10", item: "Toiletries & makeup", category: "essentials", checked: false },
  { id: "11", item: "ID & credit cards", category: "essentials", checked: false },
  { id: "12", item: "Cash for tips", category: "essentials", checked: false },
  { id: "13", item: "Beach towel", category: "beach", checked: false },
  { id: "14", item: "Beach bag", category: "beach", checked: false },
  { id: "15", item: "Reusable water bottle", category: "beach", checked: false },
  { id: "16", item: "Hair products for humidity", category: "beauty", checked: false },
  { id: "17", item: "Waterproof mascara", category: "beauty", checked: false },
  { id: "18", item: "Cute accessories / jewelry", category: "beauty", checked: false },
];

// Loading Screen Component
function LoadingScreen() {
  return (
    <div className="fixed inset-0 bg-gradient-to-br from-[#FF3CAC] via-[#FF6B35] to-[#FFBD00] flex items-center justify-center z-50">
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        className="text-center"
      >
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
          className="w-20 h-20 border-4 border-white/30 border-t-white rounded-full mx-auto mb-6"
        />
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="text-4xl font-black font-playfair text-white mb-2"
        >
          Miami, baby!
        </motion.h1>
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="text-white/70"
        >
          Loading your trip planner...
        </motion.p>
      </motion.div>
    </div>
  );
}

// Countdown Component
function CountdownTimer() {
  const [timeLeft, setTimeLeft] = useState({ days: 0, hours: 0, minutes: 0, seconds: 0 });

  useEffect(() => {
    const targetDate = new Date('2026-03-16T00:00:00').getTime();
    
    const updateCountdown = () => {
      const now = new Date().getTime();
      const distance = targetDate - now;
      
      if (distance > 0) {
        setTimeLeft({
          days: Math.floor(distance / (1000 * 60 * 60 * 24)),
          hours: Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
          minutes: Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60)),
          seconds: Math.floor((distance % (1000 * 60)) / 1000),
        });
      }
    };

    updateCountdown();
    const interval = setInterval(updateCountdown, 1000);
    return () => clearInterval(interval);
  }, []);

  const timeBlocks = [
    { value: timeLeft.days, label: 'DAYS' },
    { value: timeLeft.hours, label: 'HRS' },
    { value: timeLeft.minutes, label: 'MIN' },
    { value: timeLeft.seconds, label: 'SEC' },
  ];

  return (
    <div className="flex gap-3 justify-center flex-wrap">
      {timeBlocks.map((block, i) => (
        <motion.div
          key={block.label}
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: i * 0.1 }}
          className="bg-white/20 backdrop-blur-md border border-white/30 rounded-2xl px-4 py-3 min-w-[70px]"
        >
          <div className="text-3xl md:text-4xl font-bold text-white font-playfair">
            {String(block.value).padStart(2, '0')}
          </div>
          <div className="text-[10px] text-white/70 font-dmsans tracking-widest">{block.label}</div>
        </motion.div>
      ))}
    </div>
  );
}

// Sortable Activity Item Component
interface SortableActivityItemProps {
  activity: Activity;
  day: Day;
  currentUser: string;
  onVote: (dayId: string, activityId: string) => void;
  onAddComment: (dayId: string, activityId: string, text: string) => void;
  onDeleteActivity: (dayId: string, activityId: string) => void;
  onEditActivity: (dayId: string, activity: Activity) => void;
}

function SortableActivityItem({ 
  activity, 
  day, 
  currentUser, 
  onVote, 
  onAddComment, 
  onDeleteActivity,
  onEditActivity 
}: SortableActivityItemProps) {
  const [showComments, setShowComments] = useState(false);
  const [commentText, setCommentText] = useState('');
  const tagStyle = tagStyles[activity.tag];
  const hasVoted = activity.votedBy.includes(currentUser);
  
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: activity.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  const handleSubmitComment = () => {
    if (commentText.trim()) {
      onAddComment(day.id, activity.id, commentText);
      setCommentText('');
    }
  };

  return (
    <motion.div
      ref={setNodeRef}
      style={style}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100 hover:shadow-lg transition-shadow"
    >
      <div className="flex flex-col md:flex-row md:items-start gap-4">
        {/* Drag Handle & Time & Vote */}
        <div className="flex md:flex-col items-center md:items-center gap-3 md:w-24">
          <div 
            {...attributes}
            {...listeners}
            className="cursor-grab active:cursor-grabbing p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <GripVertical className="w-5 h-5 text-gray-400" />
          </div>
          <div 
            className="px-3 py-1.5 rounded-full text-xs font-bold text-white"
            style={{ background: day.accent }}
          >
            {activity.time}
          </div>
          <button
            onClick={() => onVote(day.id, activity.id)}
            className={`flex flex-col items-center gap-1 p-2 rounded-xl transition-all ${
              hasVoted 
                ? 'bg-pink-100 text-pink-600' 
                : 'bg-gray-100 text-gray-400 hover:bg-pink-50 hover:text-pink-500'
            }`}
          >
            <Heart className={`w-5 h-5 ${hasVoted ? 'fill-current' : ''}`} />
            <span className="text-xs font-bold">{activity.votes}</span>
          </button>
        </div>

        {/* Content */}
        <div className="flex-1">
          <div className="flex flex-wrap items-center gap-2 mb-2">
            <h3 className="text-xl font-bold font-playfair text-gray-800">
              {activity.title}
            </h3>
            <Badge 
              className="flex items-center gap-1"
              style={{ background: tagStyle.bg, color: tagStyle.color }}
            >
              {tagStyle.icon}
              {tagLabels[activity.tag]}
            </Badge>
            <div className="flex gap-1 ml-auto">
              <button
                onClick={() => onEditActivity(day.id, activity)}
                className="p-1.5 hover:bg-gray-100 rounded-lg transition-colors text-gray-400 hover:text-gray-600"
              >
                <Edit3 className="w-4 h-4" />
              </button>
              <button
                onClick={() => onDeleteActivity(day.id, activity.id)}
                className="p-1.5 hover:bg-red-50 rounded-lg transition-colors text-gray-400 hover:text-red-500"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
          
          {activity.place && (
            <div className="flex items-center gap-1.5 text-gray-400 text-sm mb-3">
              <MapPin className="w-4 h-4" />
              {activity.place}
            </div>
          )}
          
          <p className="text-gray-600 leading-relaxed mb-4">
            {activity.desc}
          </p>
          
          <div 
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold"
            style={{ background: day.bg, color: day.accent }}
          >
            <DollarSign className="w-4 h-4" />
            {activity.price}
          </div>

          {/* Comments Section */}
          <div className="mt-4 pt-4 border-t border-gray-100">
            <button
              onClick={() => setShowComments(!showComments)}
              className="flex items-center gap-2 text-sm text-gray-500 hover:text-gray-700 transition-colors"
            >
              <MessageCircle className="w-4 h-4" />
              {activity.comments.length > 0 ? `${activity.comments.length} comments` : 'Add a comment'}
            </button>

            <AnimatePresence>
              {showComments && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="overflow-hidden"
                >
                  <div className="mt-3 space-y-3">
                    {activity.comments.map((comment) => (
                      <div key={comment.id} className="bg-gray-50 rounded-xl p-3">
                        <div className="flex items-center gap-2 mb-1">
                          <div 
                            className="w-6 h-6 rounded-full flex items-center justify-center text-white text-xs font-bold"
                            style={{ background: day.accent }}
                          >
                            {comment.user[0]}
                          </div>
                          <span className="text-sm font-semibold">{comment.user}</span>
                          <span className="text-xs text-gray-400">
                            {new Date(comment.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                        <p className="text-sm text-gray-600 ml-8">{comment.text}</p>
                      </div>
                    ))}
                    
                    <div className="flex gap-2">
                      <Input
                        value={commentText}
                        onChange={(e) => setCommentText(e.target.value)}
                        placeholder="Share your thoughts or suggest an alternative..."
                        className="flex-1 text-sm"
                        onKeyDown={(e) => e.key === 'Enter' && handleSubmitComment()}
                      />
                      <Button
                        onClick={handleSubmitComment}
                        size="sm"
                        className="px-3"
                        style={{ background: day.accent }}
                      >
                        <Send className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>

      {/* Voted by avatars */}
      {activity.votedBy.length > 0 && (
        <div className="mt-4 pt-4 border-t border-gray-100 flex items-center gap-2">
          <span className="text-xs text-gray-400">Voted by:</span>
          <div className="flex -space-x-2">
            {activity.votedBy.map((user, idx) => (
              <div
                key={idx}
                className="w-7 h-7 rounded-full bg-gradient-to-br from-[#FF3CAC] to-[#FFBD00] flex items-center justify-center text-white text-xs font-bold border-2 border-white"
                title={user}
              >
                {user[0]}
              </div>
            ))}
          </div>
        </div>
      )}
    </motion.div>
  );
}

// Add Activity Modal
interface AddActivityModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (activity: Partial<Activity>) => void;
  day: Day;
  editingActivity?: Activity | null;
}

function AddActivityModal({ isOpen, onClose, onSave, day, editingActivity }: AddActivityModalProps) {
  const [formData, setFormData] = useState<Partial<Activity>>({
    time: '',
    title: '',
    place: '',
    desc: '',
    price: '',
    tag: 'activity',
  });

  useEffect(() => {
    if (editingActivity) {
      setFormData(editingActivity);
    } else {
      setFormData({
        time: '',
        title: '',
        place: '',
        desc: '',
        price: '',
        tag: 'activity',
      });
    }
  }, [editingActivity, isOpen]);

  if (!isOpen) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
    >
      <motion.div
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        className="bg-white rounded-3xl p-6 max-w-lg w-full shadow-2xl max-h-[90vh] overflow-y-auto"
      >
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold font-playfair">
            {editingActivity ? 'Edit Activity' : 'Add New Activity'}
          </h2>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">Time</label>
              <Input
                value={formData.time}
                onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                placeholder="e.g., 3 PM"
              />
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">Category</label>
              <select
                value={formData.tag}
                onChange={(e) => setFormData({ ...formData, tag: e.target.value })}
                className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm"
              >
                {Object.keys(tagLabels).map(tag => (
                  <option key={tag} value={tag}>{tagLabels[tag]}</option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="text-sm font-medium text-gray-700 mb-1 block">Title</label>
            <Input
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              placeholder="Activity name"
            />
          </div>

          <div>
            <label className="text-sm font-medium text-gray-700 mb-1 block">Location</label>
            <Input
              value={formData.place || ''}
              onChange={(e) => setFormData({ ...formData, place: e.target.value })}
              placeholder="Address or place name"
            />
          </div>

          <div>
            <label className="text-sm font-medium text-gray-700 mb-1 block">Description</label>
            <Textarea
              value={formData.desc}
              onChange={(e) => setFormData({ ...formData, desc: e.target.value })}
              placeholder="What's this activity about?"
              rows={3}
            />
          </div>

          <div>
            <label className="text-sm font-medium text-gray-700 mb-1 block">Price</label>
            <Input
              value={formData.price}
              onChange={(e) => setFormData({ ...formData, price: e.target.value })}
              placeholder="e.g., $25/person"
            />
          </div>

          <Button
            onClick={() => onSave(formData)}
            className="w-full"
            style={{ background: day.accent }}
          >
            {editingActivity ? 'Save Changes' : 'Add Activity'}
          </Button>
        </div>
      </motion.div>
    </motion.div>
  );
}

// Share Modal
interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  days: Day[];
  packingList: PackingItem[];
  currentUser: string;
  onImport: (data: TripData) => void;
}

function ShareModal({ isOpen, onClose, days, packingList, currentUser, onImport }: ShareModalProps) {
  const [importText, setImportText] = useState('');
  const [showImport, setShowImport] = useState(false);
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const exportData: TripData = {
    days,
    packingList,
    lastUpdated: Date.now(),
    updatedBy: currentUser,
  };

  const exportJson = JSON.stringify(exportData, null, 2);

  const handleCopy = () => {
    navigator.clipboard.writeText(exportJson);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleImport = () => {
    try {
      const data = JSON.parse(importText) as TripData;
      onImport(data);
      setImportText('');
      setShowImport(false);
      onClose();
    } catch (e) {
      alert('Invalid JSON. Please paste the complete shared data.');
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
    >
      <motion.div
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        className="bg-white rounded-3xl p-6 max-w-lg w-full shadow-2xl max-h-[90vh] overflow-y-auto"
      >
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold font-playfair flex items-center gap-2">
            <Share2 className="w-5 h-5" />
            Share Trip Data
          </h2>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-6">
          <div className="flex items-start gap-2">
            <Info className="w-5 h-5 text-blue-500 mt-0.5" />
            <div className="text-sm text-blue-700">
              <p className="font-semibold mb-1">How sharing works:</p>
              <p>Since this is a free app without a server, data is saved in your browser only.</p>
              <p className="mt-1">To share with friends:</p>
              <ol className="list-decimal ml-4 mt-1 space-y-0.5">
                <li>Click "Copy Data" below</li>
                <li>Paste in your group chat</li>
                <li>Friends click "Import" and paste the data</li>
              </ol>
            </div>
          </div>
        </div>

        {!showImport ? (
          <div className="space-y-4">
            <div className="bg-gray-50 rounded-xl p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-700">Your Trip Data</span>
                <span className="text-xs text-gray-400">
                  Last updated: {new Date(exportData.lastUpdated).toLocaleString()}
                </span>
              </div>
              <pre className="text-xs bg-gray-800 text-gray-100 p-3 rounded-lg overflow-x-auto max-h-32">
                {exportJson.slice(0, 200)}...
              </pre>
            </div>

            <div className="flex gap-3">
              <Button
                onClick={handleCopy}
                className="flex-1 bg-gradient-to-r from-[#FF3CAC] to-[#FF6B35]"
              >
                {copied ? <CheckCircle2 className="w-4 h-4 mr-2" /> : <Download className="w-4 h-4 mr-2" />}
                {copied ? 'Copied!' : 'Copy Data'}
              </Button>
              <Button
                onClick={() => setShowImport(true)}
                variant="outline"
                className="flex-1"
              >
                <Upload className="w-4 h-4 mr-2" />
                Import
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <Textarea
              value={importText}
              onChange={(e) => setImportText(e.target.value)}
              placeholder="Paste the shared trip data here..."
              rows={8}
              className="font-mono text-xs"
            />
            <div className="flex gap-3">
              <Button
                onClick={handleImport}
                className="flex-1 bg-gradient-to-r from-[#FF3CAC] to-[#FF6B35]"
              >
                <Upload className="w-4 h-4 mr-2" />
                Import Data
              </Button>
              <Button
                onClick={() => setShowImport(false)}
                variant="outline"
              >
                Back
              </Button>
            </div>
          </div>
        )}
      </motion.div>
    </motion.div>
  );
}

// Map View Component
interface MapViewProps {
  days: Day[];
}

function MapView({ days }: MapViewProps) {
  const allActivities = days.flatMap(d => d.activities.map(a => ({ ...a, dayColor: d.accent, dayLabel: d.label })));
  const activitiesWithCoords = allActivities.filter(a => a.lat && a.lng);
  
  return (
    <div className="space-y-6">
      <Card className="border-0 shadow-lg rounded-3xl overflow-hidden">
        <CardHeader className="bg-gradient-to-r from-[#FF3CAC] to-[#FF6B35] text-white">
          <CardTitle className="text-xl font-playfair flex items-center gap-2">
            <Map className="w-6 h-6" />
            Trip Map
          </CardTitle>
          <p className="text-white/70 text-sm">All your activities plotted around Miami</p>
        </CardHeader>
        <CardContent className="p-6">
          {/* Stylized Map */}
          <div className="relative bg-gradient-to-br from-blue-50 to-blue-100 rounded-2xl overflow-hidden" style={{ height: '500px' }}>
            {/* Map Background Pattern */}
            <div className="absolute inset-0 opacity-30">
              <svg width="100%" height="100%">
                <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                  <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#90caf9" strokeWidth="0.5"/>
                </pattern>
                <rect width="100%" height="100%" fill="url(#grid)" />
              </svg>
            </div>
            
            {/* Water areas */}
            <div className="absolute top-0 right-0 w-1/3 h-full bg-blue-200/50 rounded-l-full" />
            <div className="absolute bottom-0 left-1/4 w-1/2 h-1/3 bg-blue-200/50 rounded-t-full" />
            
            {/* Airbnb - Central Hub */}
            <div 
              className="absolute flex flex-col items-center"
              style={{ left: '45%', top: '55%', transform: 'translate(-50%, -50%)' }}
            >
              <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-purple-600 rounded-full flex items-center justify-center shadow-lg border-4 border-white z-10">
                <Home className="w-6 h-6 text-white" />
              </div>
              <div className="mt-1 bg-purple-600 text-white text-xs px-2 py-1 rounded-full font-semibold whitespace-nowrap">
                Airbnb Hub
              </div>
            </div>

            {/* Activity Pins */}
            {activitiesWithCoords.map((activity) => {
              const normalizedX = ((activity.lng! + 80.3) / 0.2) * 80 + 10;
              const normalizedY = ((25.82 - activity.lat!) / 0.07) * 80 + 10;
              
              return (
                <div
                  key={activity.id}
                  className="absolute flex flex-col items-center group cursor-pointer"
                  style={{ 
                    left: `${Math.max(5, Math.min(90, normalizedX))}%`, 
                    top: `${Math.max(5, Math.min(90, normalizedY))}%`,
                    transform: 'translate(-50%, -50%)'
                  }}
                >
                  <div 
                    className="w-8 h-8 rounded-full flex items-center justify-center shadow-md border-2 border-white transition-transform group-hover:scale-110"
                    style={{ background: activity.dayColor }}
                  >
                    <MapPin className="w-4 h-4 text-white" />
                  </div>
                  <div className="opacity-0 group-hover:opacity-100 transition-opacity mt-1 bg-gray-800 text-white text-xs px-2 py-1 rounded-lg whitespace-nowrap z-20">
                    {activity.title}
                  </div>
                </div>
              );
            })}

            {/* Legend */}
            <div className="absolute bottom-4 left-4 bg-white/90 backdrop-blur-sm rounded-xl p-3 shadow-lg">
              <div className="text-xs font-semibold text-gray-600 mb-2">Legend</div>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 bg-purple-500 rounded-full flex items-center justify-center">
                    <Home className="w-2 h-2 text-white" />
                  </div>
                  <span className="text-xs text-gray-600">Airbnb (Home Base)</span>
                </div>
                {days.map(d => (
                  <div key={d.id} className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full" style={{ background: d.accent }} />
                    <span className="text-xs text-gray-600">{d.label}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Activity List by Location */}
          <div className="mt-6 grid md:grid-cols-2 gap-4">
            <div>
              <h3 className="font-bold text-gray-700 mb-3 flex items-center gap-2">
                <Navigation className="w-4 h-4" />
                Nearby Airbnb (Walking Distance)
              </h3>
              <div className="space-y-2">
                {allActivities
                  .filter(a => a.place?.includes('Brickell') || a.place?.includes('walkable'))
                  .map(a => (
                    <div key={a.id} className="flex items-center gap-2 text-sm">
                      <div className="w-2 h-2 rounded-full" style={{ background: a.dayColor }} />
                      <span className="text-gray-600">{a.title}</span>
                    </div>
                  ))}
              </div>
            </div>
            <div>
              <h3 className="font-bold text-gray-700 mb-3 flex items-center gap-2">
                <MapPin className="w-4 h-4" />
                Beach Area (Miami Beach)
              </h3>
              <div className="space-y-2">
                {allActivities
                  .filter(a => a.place?.includes('Beach') || a.place?.includes('Collins'))
                  .map(a => (
                    <div key={a.id} className="flex items-center gap-2 text-sm">
                      <div className="w-2 h-2 rounded-full" style={{ background: a.dayColor }} />
                      <span className="text-gray-600">{a.title}</span>
                    </div>
                  ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Main App
function App() {
  const [isLoading, setIsLoading] = useState(true);
  const [activeDay, setActiveDay] = useState("mon");
  const [days, setDays] = useState<Day[]>(createInitialDays);
  const [packingList, setPackingList] = useState(initialPackingList);
  const [currentUser, setCurrentUser] = useState<string>("");
  const [showUserModal, setShowUserModal] = useState(false);
  const [activeTab, setActiveTab] = useState("itinerary");
  const [showAddModal, setShowAddModal] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [editingActivity, setEditingActivity] = useState<Activity | null>(null);
  const [dataNoticeDismissed, setDataNoticeDismissed] = useState(false);

  const day = days.find(d => d.id === activeDay)!;

  // DnD sensors
  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  // Load data from localStorage
  useEffect(() => {
    const loadData = () => {
      const savedDays = localStorage.getItem('miamiTrip_days');
      const savedPacking = localStorage.getItem('miamiTrip_packing');
      const savedUser = localStorage.getItem('miamiTrip_user');
      const savedNotice = localStorage.getItem('miamiTrip_noticeDismissed');
      
      if (savedDays) {
        try {
          const parsed = JSON.parse(savedDays);
          // Restore icon functions (they get lost in JSON)
          setDays(parsed.map((d: Day, i: number) => ({
            ...d,
            icon: createInitialDays()[i].icon
          })));
        } catch {
          setDays(createInitialDays());
        }
      }
      if (savedPacking) setPackingList(JSON.parse(savedPacking));
      if (savedUser) {
        setCurrentUser(savedUser);
      } else {
        setShowUserModal(true);
      }
      if (savedNotice) setDataNoticeDismissed(true);
      
      // Simulate loading for smoother experience
      setTimeout(() => setIsLoading(false), 800);
    };

    loadData();
  }, []);

  // Save to localStorage
  useEffect(() => {
    if (!isLoading) {
      localStorage.setItem('miamiTrip_days', JSON.stringify(days));
    }
  }, [days, isLoading]);

  useEffect(() => {
    if (!isLoading) {
      localStorage.setItem('miamiTrip_packing', JSON.stringify(packingList));
    }
  }, [packingList, isLoading]);

  const handleSetUser = (name: string) => {
    setCurrentUser(name);
    localStorage.setItem('miamiTrip_user', name);
    setShowUserModal(false);
    triggerConfetti();
  };

  const triggerConfetti = useCallback(() => {
    confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#FF3CAC', '#FF6B35', '#FFBD00', '#E8007D']
    });
  }, []);

  const handleVote = (dayId: string, activityId: string) => {
    if (!currentUser) {
      setShowUserModal(true);
      return;
    }

    setDays(prevDays => {
      const newDays = [...prevDays];
      const day = newDays.find(d => d.id === dayId)!;
      const activity = day.activities.find(a => a.id === activityId)!;
      
      if (activity.votedBy.includes(currentUser)) {
        activity.votes--;
        activity.votedBy = activity.votedBy.filter(u => u !== currentUser);
      } else {
        activity.votes++;
        activity.votedBy.push(currentUser);
        triggerConfetti();
      }
      
      return newDays;
    });
  };

  const handleAddComment = (dayId: string, activityId: string, text: string) => {
    if (!currentUser) {
      setShowUserModal(true);
      return;
    }

    setDays(prevDays => {
      const newDays = [...prevDays];
      const day = newDays.find(d => d.id === dayId)!;
      const activity = day.activities.find(a => a.id === activityId)!;
      
      activity.comments.push({
        id: generateId(),
        user: currentUser,
        text,
        timestamp: Date.now(),
      });
      
      return newDays;
    });
  };

  const handleDeleteActivity = (dayId: string, activityId: string) => {
    if (!confirm('Are you sure you want to delete this activity?')) return;
    
    setDays(prevDays => {
      const newDays = [...prevDays];
      const day = newDays.find(d => d.id === dayId)!;
      day.activities = day.activities.filter(a => a.id !== activityId);
      return newDays;
    });
  };

  const handleEditActivity = (_dayId: string, activity: Activity) => {
    setEditingActivity(activity);
    setShowAddModal(true);
  };

  const handleSaveActivity = (formData: Partial<Activity>) => {
    if (editingActivity) {
      setDays(prevDays => {
        const newDays = [...prevDays];
        const day = newDays.find(d => d.id === activeDay)!;
        const idx = day.activities.findIndex(a => a.id === editingActivity.id);
        if (idx !== -1) {
          day.activities[idx] = { ...day.activities[idx], ...formData } as Activity;
        }
        return newDays;
      });
    } else {
      setDays(prevDays => {
        const newDays = [...prevDays];
        const day = newDays.find(d => d.id === activeDay)!;
        day.activities.push({
          ...formData,
          id: generateId(),
          votes: 0,
          votedBy: [],
          comments: [],
        } as Activity);
        return newDays;
      });
    }
    setShowAddModal(false);
    setEditingActivity(null);
    triggerConfetti();
  };

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;

    if (over && active.id !== over.id) {
      setDays(prevDays => {
        const newDays = [...prevDays];
        const day = newDays.find(d => d.id === activeDay)!;
        const oldIndex = day.activities.findIndex(a => a.id === active.id);
        const newIndex = day.activities.findIndex(a => a.id === over.id);
        day.activities = arrayMove(day.activities, oldIndex, newIndex);
        return newDays;
      });
    }
  };

  const handleImport = (data: TripData) => {
    setDays(data.days.map((d, i) => ({
      ...d,
      icon: createInitialDays()[i]?.icon || null
    })));
    setPackingList(data.packingList);
    triggerConfetti();
  };

  const togglePackingItem = (id: string) => {
    setPackingList(prev => 
      prev.map(item => 
        item.id === id ? { ...item, checked: !item.checked } : item
      )
    );
  };

  const dismissNotice = () => {
    setDataNoticeDismissed(true);
    localStorage.setItem('miamiTrip_noticeDismissed', 'true');
  };

  const packingProgress = Math.round((packingList.filter(i => i.checked).length / packingList.length) * 100);

  const totalBudget = days.reduce((acc, day) => {
    const min = parseInt(day.budget.replace(/[^0-9]/g, '').slice(0, 2)) || 0;
    const max = parseInt(day.budget.replace(/[^0-9]/g, '').slice(2)) || min;
    return acc + (min + max) / 2;
  }, 0);

  const userNames = ['Anika', 'Misha', 'Sadhika', 'Pavithra', 'Ela'];

  if (isLoading) {
    return <LoadingScreen />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FFF5F0] via-[#FFF0F7] to-[#FFFDF0] font-dmsans overflow-x-hidden">
      {/* User Modal */}
      <AnimatePresence>
        {showUserModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              className="bg-white rounded-3xl p-8 max-w-md w-full shadow-2xl"
            >
              <div className="text-center mb-6">
                <div className="w-16 h-16 bg-gradient-to-br from-[#FF3CAC] to-[#FF6B35] rounded-full flex items-center justify-center mx-auto mb-4">
                  <Sparkles className="w-8 h-8 text-white" />
                </div>
                <h2 className="text-2xl font-bold font-playfair text-gray-800">Who's ready for Miami? 🌴</h2>
                <p className="text-gray-500 mt-2">Pick your name to vote, comment, and track packing!</p>
              </div>
              <div className="space-y-3">
                {userNames.map(name => (
                  <button
                    key={name}
                    onClick={() => handleSetUser(name)}
                    className="w-full py-3 px-4 rounded-xl border-2 border-gray-100 hover:border-[#FF3CAC] hover:bg-[#FFF0F7] transition-all text-left flex items-center gap-3"
                  >
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#FF3CAC] to-[#FFBD00] flex items-center justify-center text-white font-bold">
                      {name[0]}
                    </div>
                    <span className="font-medium">{name}</span>
                  </button>
                ))}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Share Modal */}
      <ShareModal
        isOpen={showShareModal}
        onClose={() => setShowShareModal(false)}
        days={days}
        packingList={packingList}
        currentUser={currentUser}
        onImport={handleImport}
      />

      {/* Add Activity Modal */}
      <AddActivityModal
        isOpen={showAddModal}
        onClose={() => { setShowAddModal(false); setEditingActivity(null); }}
        onSave={handleSaveActivity}
        day={day}
        editingActivity={editingActivity}
      />

      {/* Header */}
      <header className="relative bg-gradient-to-br from-[#FF3CAC] via-[#FF6B35] to-[#FFBD00] px-4 py-12 md:py-16 text-center overflow-hidden">
        {/* Animated background elements */}
        <div className="absolute inset-0 overflow-hidden">
          {[...Array(6)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute rounded-full bg-white/10"
              style={{
                width: 40 + i * 20,
                height: 40 + i * 20,
                left: `${10 + i * 15}%`,
                top: `${20 + (i % 3) * 20}%`,
              }}
              animate={{
                y: [0, -20, 0],
                scale: [1, 1.1, 1],
              }}
              transition={{
                duration: 3 + i * 0.5,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            />
          ))}
        </div>

        <div className="relative z-10">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-md border border-white/30 rounded-full px-4 py-2 mb-6"
          >
            <Sparkles className="w-4 h-4 text-white" />
            <span className="text-white text-sm font-semibold tracking-wider">GIRLS TRIP 2026</span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.1 }}
            className="text-5xl md:text-7xl font-black font-playfair text-white mb-4 drop-shadow-lg"
          >
            Miami, baby! 🌴
          </motion.h1>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="text-white/80 text-lg mb-8"
          >
            March 16–21 · 1200 Brickell Bay Dr · 5 besties
          </motion.p>

          {/* Countdown */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <p className="text-white/60 text-sm mb-3 tracking-widest uppercase">Trip starts in</p>
            <CountdownTimer />
          </motion.div>

          {/* User badge & Share button */}
          {currentUser && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              className="absolute top-4 right-4 flex flex-col items-end gap-2"
            >
              <button
                onClick={() => setShowShareModal(true)}
                className="bg-white/20 backdrop-blur-md border border-white/30 rounded-full px-3 py-1.5 flex items-center gap-2 hover:bg-white/30 transition-colors"
              >
                <Share2 className="w-4 h-4 text-white" />
                <span className="text-white text-sm">Share</span>
              </button>
              <div className="bg-white/20 backdrop-blur-md border border-white/30 rounded-full px-3 py-1.5 flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-gradient-to-br from-[#FF3CAC] to-[#FFBD00] flex items-center justify-center text-white text-xs font-bold">
                  {currentUser[0]}
                </div>
                <span className="text-white text-sm">{currentUser}</span>
                <button onClick={() => setShowUserModal(true)} className="text-white/60 hover:text-white">
                  <RefreshCw className="w-3 h-3" />
                </button>
              </div>
            </motion.div>
          )}
        </div>
      </header>

      {/* Data Notice Banner */}
      {!dataNoticeDismissed && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-blue-50 border-b border-blue-200 px-4 py-3"
        >
          <div className="max-w-6xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm text-blue-700">
              <Info className="w-4 h-4 flex-shrink-0" />
              <span>Data is saved in your browser. Click "Share" to sync with friends!</span>
            </div>
            <button onClick={dismissNotice} className="text-blue-500 hover:text-blue-700">
              <X className="w-4 h-4" />
            </button>
          </div>
        </motion.div>
      )}

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="w-full grid grid-cols-4 mb-8 bg-white/50 backdrop-blur-sm p-1 rounded-2xl">
            <TabsTrigger value="itinerary" className="rounded-xl data-[state=active]:bg-white data-[state=active]:shadow-md">
              <Calendar className="w-4 h-4 mr-2" />
              Itinerary
            </TabsTrigger>
            <TabsTrigger value="map" className="rounded-xl data-[state=active]:bg-white data-[state=active]:shadow-md">
              <Map className="w-4 h-4 mr-2" />
              Map
            </TabsTrigger>
            <TabsTrigger value="packing" className="rounded-xl data-[state=active]:bg-white data-[state=active]:shadow-md">
              <ShoppingBag className="w-4 h-4 mr-2" />
              Packing
            </TabsTrigger>
            <TabsTrigger value="budget" className="rounded-xl data-[state=active]:bg-white data-[state=active]:shadow-md">
              <DollarSign className="w-4 h-4 mr-2" />
              Budget
            </TabsTrigger>
          </TabsList>

          {/* Itinerary Tab */}
          <TabsContent value="itinerary" className="space-y-6">
            {/* Day Tabs */}
            <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
              {days.map((d) => (
                <button
                  key={d.id}
                  onClick={() => setActiveDay(d.id)}
                  className={`flex-shrink-0 px-4 py-3 rounded-2xl border-2 transition-all duration-300 ${
                    activeDay === d.id
                      ? 'text-white shadow-lg scale-105'
                      : 'bg-white border-gray-200 text-gray-600 hover:border-gray-300'
                  }`}
                  style={{
                    background: activeDay === d.id ? d.accent : undefined,
                    borderColor: activeDay === d.id ? d.accent : undefined,
                  }}
                >
                  <div className="text-xs opacity-70 mb-0.5">{d.date}</div>
                  <div className="font-semibold flex items-center gap-1.5">
                    {d.label}
                  </div>
                </button>
              ))}
            </div>

            {/* Day Content */}
            <AnimatePresence mode="wait">
              <motion.div
                key={activeDay}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                {/* Day Header */}
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                  <div>
                    <h2 className="text-3xl font-bold font-playfair" style={{ color: day.accent }}>
                      {day.label}
                    </h2>
                    <p className="text-gray-500 flex items-center gap-2 mt-1">
                      <Sparkles className="w-4 h-4" />
                      {day.vibe}
                    </p>
                  </div>
                  <div className="flex gap-3">
                    <div 
                      className="px-6 py-3 rounded-2xl border-2"
                      style={{ background: day.bg, borderColor: day.accent + '40' }}
                    >
                      <div className="text-xs text-gray-400 uppercase tracking-wider">Daily Budget</div>
                      <div className="text-2xl font-bold font-playfair" style={{ color: day.accent }}>
                        {day.budget}
                      </div>
                      <div className="text-xs text-gray-400">per person</div>
                    </div>
                    <button
                      onClick={() => setShowAddModal(true)}
                      className="px-4 py-3 rounded-2xl text-white font-semibold flex items-center gap-2 hover:opacity-90 transition-opacity"
                      style={{ background: day.accent }}
                    >
                      <Plus className="w-5 h-5" />
                      Add
                    </button>
                  </div>
                </div>

                {/* Draggable Activities */}
                <DndContext
                  sensors={sensors}
                  collisionDetection={closestCenter}
                  onDragEnd={handleDragEnd}
                >
                  <SortableContext
                    items={day.activities.map(a => a.id)}
                    strategy={verticalListSortingStrategy}
                  >
                    <div className="space-y-4">
                      {day.activities.map((activity) => (
                        <SortableActivityItem
                          key={activity.id}
                          activity={activity}
                          day={day}
                          currentUser={currentUser}
                          onVote={handleVote}
                          onAddComment={handleAddComment}
                          onDeleteActivity={handleDeleteActivity}
                          onEditActivity={handleEditActivity}
                        />
                      ))}
                    </div>
                  </SortableContext>
                </DndContext>
              </motion.div>
            </AnimatePresence>
          </TabsContent>

          {/* Map Tab */}
          <TabsContent value="map">
            <MapView days={days} />
          </TabsContent>

          {/* Packing Tab */}
          <TabsContent value="packing" className="space-y-6">
            <Card className="border-0 shadow-lg rounded-3xl overflow-hidden">
              <CardHeader className="bg-gradient-to-r from-[#FF3CAC] to-[#FF6B35] text-white">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-2xl font-playfair flex items-center gap-2">
                      <ShoppingBag className="w-6 h-6" />
                      Packing List
                    </CardTitle>
                    <p className="text-white/70 mt-1">Don't forget the essentials!</p>
                  </div>
                  <div className="text-right">
                    <div className="text-3xl font-bold">{packingProgress}%</div>
                    <div className="text-white/70 text-sm">packed</div>
                  </div>
                </div>
                <Progress value={packingProgress} className="mt-4 h-2 bg-white/20" />
              </CardHeader>
              <CardContent className="p-6">
                <div className="grid md:grid-cols-2 gap-6">
                  {['clothes', 'essentials', 'beach', 'beauty'].map(category => {
                    const items = packingList.filter(i => i.category === category);
                    const categoryNames: Record<string, string> = {
                      clothes: '👗 Clothes & Shoes',
                      essentials: '✨ Essentials',
                      beach: '🏖️ Beach Gear',
                      beauty: '💄 Beauty & Accessories'
                    };
                    
                    return (
                      <div key={category} className="space-y-3">
                        <h3 className="font-bold text-gray-700 flex items-center gap-2">
                          {categoryNames[category]}
                        </h3>
                        <div className="space-y-2">
                          {items.map(item => (
                            <label
                              key={item.id}
                              className={`flex items-center gap-3 p-3 rounded-xl border-2 cursor-pointer transition-all ${
                                item.checked 
                                  ? 'bg-green-50 border-green-200' 
                                  : 'bg-white border-gray-100 hover:border-gray-200'
                              }`}
                            >
                              <Checkbox
                                checked={item.checked}
                                onCheckedChange={() => togglePackingItem(item.id)}
                                className="w-5 h-5"
                              />
                              <span className={`flex-1 ${item.checked ? 'line-through text-gray-400' : 'text-gray-700'}`}>
                                {item.item}
                              </span>
                              {item.checked && <CheckCircle2 className="w-5 h-5 text-green-500" />}
                            </label>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Budget Tab */}
          <TabsContent value="budget" className="space-y-6">
            <div className="grid md:grid-cols-3 gap-4">
              <Card className="border-0 shadow-lg rounded-3xl bg-gradient-to-br from-green-400 to-green-500 text-white">
                <CardContent className="p-6">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                      <DollarSign className="w-5 h-5" />
                    </div>
                    <span className="text-white/80">On a Budget</span>
                  </div>
                  <div className="text-4xl font-bold font-playfair">~$780</div>
                  <div className="text-white/70 text-sm">per person</div>
                </CardContent>
              </Card>
              
              <Card className="border-0 shadow-lg rounded-3xl bg-gradient-to-br from-[#FF3CAC] to-[#FF6B35] text-white">
                <CardContent className="p-6">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                      <TrendingUp className="w-5 h-5" />
                    </div>
                    <span className="text-white/80">Normal Spend</span>
                  </div>
                  <div className="text-4xl font-bold font-playfair">~$1,050</div>
                  <div className="text-white/70 text-sm">per person</div>
                </CardContent>
              </Card>
              
              <Card className="border-0 shadow-lg rounded-3xl bg-gradient-to-br from-[#E8007D] to-[#FFBD00] text-white">
                <CardContent className="p-6">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                      <PartyPopper className="w-5 h-5" />
                    </div>
                    <span className="text-white/80">Party Mode</span>
                  </div>
                  <div className="text-4xl font-bold font-playfair">~$1,500</div>
                  <div className="text-white/70 text-sm">per person</div>
                </CardContent>
              </Card>
            </div>

            <Card className="border-0 shadow-lg rounded-3xl">
              <CardHeader>
                <CardTitle className="text-xl font-playfair">Daily Budget Breakdown</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {days.map((d, i) => (
                    <div key={d.id} className="flex items-center gap-4">
                      <div 
                        className="w-12 h-12 rounded-2xl flex items-center justify-center text-white"
                        style={{ background: d.accent }}
                      >
                        {d.label.slice(0, 3)}
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between mb-1">
                          <span className="font-semibold">{d.label}</span>
                          <span className="font-bold" style={{ color: d.accent }}>{d.budget}</span>
                        </div>
                        <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                          <motion.div
                            initial={{ width: 0 }}
                            animate={{ width: `${((i + 1) / days.length) * 100}%` }}
                            transition={{ delay: i * 0.1, duration: 0.5 }}
                            className="h-full rounded-full"
                            style={{ background: d.accent }}
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                
                <div className="mt-6 pt-6 border-t border-gray-100">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-500">Fixed costs (flights + Airbnb)</span>
                    <span className="font-semibold">$500</span>
                  </div>
                  <div className="flex justify-between items-center mt-2 text-lg font-bold">
                    <span>Total estimated spend</span>
                    <span className="text-[#FF3CAC]">~${(totalBudget + 500).toFixed(0)}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Money Saving Tips */}
            <Card className="border-0 shadow-lg rounded-3xl bg-gradient-to-br from-[#e8f5e9] to-[#c8e6c9]">
              <CardContent className="p-6">
                <h3 className="font-bold text-green-800 flex items-center gap-2 mb-4">
                  <Star className="w-5 h-5" />
                  Money Saving Tips
                </h3>
                <ul className="space-y-2 text-green-700">
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-5 h-5 mt-0.5 flex-shrink-0" />
                    <span>Publix grocery run saves $100+ on food & drinks</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-5 h-5 mt-0.5 flex-shrink-0" />
                    <span>Split Ubers 5 ways = only ~$5 per ride</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-5 h-5 mt-0.5 flex-shrink-0" />
                    <span>Free Miami Beach Trolley for getting around</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-5 h-5 mt-0.5 flex-shrink-0" />
                    <span>Happy hours at Rosa Sky (until 8PM weekdays)</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-100 py-8 mt-12">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <p className="text-gray-400 text-sm">
            Made with <Heart className="w-4 h-4 inline text-[#FF3CAC] fill-current" /> for the Miami Girls Trip 2026
          </p>
          <p className="text-gray-300 text-xs mt-2">
            1200 Brickell Bay Dr, Miami, FL 33131 · March 16-21 · 5 besties ready to party
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;
